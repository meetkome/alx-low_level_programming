A read me file for argv and argc
