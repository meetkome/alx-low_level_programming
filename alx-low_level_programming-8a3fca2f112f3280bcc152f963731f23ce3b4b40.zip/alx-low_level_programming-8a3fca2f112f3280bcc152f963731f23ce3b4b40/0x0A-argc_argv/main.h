#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>

int _putchar(char c);

#endif /* MAIN_H */
