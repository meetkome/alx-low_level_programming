#include "main.h"

/**
 * main - checks code
 *
 * Return: 0
 */

int main(void)
{
print_number(98);
_putchar('\n');
print_number(402);
_putchar('\n');
print_number(1024);
_putchar('\n');
print_number(0);
_putchar('\n');
print_number(-98);								
_putchar('\n');											
return (0);
}
