#include <stdio.h>
#include <unistd.h>

/**
 * main - Entry point
 *
 * Descrition: 'and that pieces of art is useful" - Dora Korpar/ 2015-10-19'
 *
 * Return: Always 0 (Success)
 */

int main(void)
{
	printf("and that piece of art is useful\" - Dora Korpar, 2015-10-19\n");
	return (1);
}
