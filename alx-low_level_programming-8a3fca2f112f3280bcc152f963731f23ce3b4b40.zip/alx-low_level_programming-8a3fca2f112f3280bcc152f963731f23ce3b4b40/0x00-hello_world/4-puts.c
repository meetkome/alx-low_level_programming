#include <stdio.h>
#include <string.h>

/**
 * main - Entry Point
 *
 * Return: Always 0 (success)
 *
 * <stdio> header
 */

int main(void)
{
char str1[70];

strcpy(str1, "\"Programming is like building a multilingual puzzle");

puts(str1);


return (0);
}
