a readme file for more arrays
