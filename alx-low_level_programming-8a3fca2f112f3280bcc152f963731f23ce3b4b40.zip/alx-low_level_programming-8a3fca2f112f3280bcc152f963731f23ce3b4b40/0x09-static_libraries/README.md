Readme for static libraries
