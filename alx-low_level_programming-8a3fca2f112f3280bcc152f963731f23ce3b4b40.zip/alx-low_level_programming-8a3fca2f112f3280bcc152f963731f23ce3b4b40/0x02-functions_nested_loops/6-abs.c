#include "main.h"

/**
 * _abs - function that computes the absolute value of an integer.
 * @a: Compute this interger.
 *
 * Return: The absolute value of an integer.
 */

int _abs(int a)
{

	if (a >= 0)
	return (a);
	else
		return (-a);
}
