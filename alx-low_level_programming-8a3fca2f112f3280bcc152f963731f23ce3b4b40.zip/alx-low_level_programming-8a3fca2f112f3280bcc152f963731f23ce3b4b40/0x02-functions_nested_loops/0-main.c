#include "main.h"

/**
 * main - tests function that prints if integer is positive or negative
 * Return: correct output when input is 0
 */

int main(void)
{
	int n;
	n = 0;
positive_or_negative(i);

return (0);
}
