a loop read me file
