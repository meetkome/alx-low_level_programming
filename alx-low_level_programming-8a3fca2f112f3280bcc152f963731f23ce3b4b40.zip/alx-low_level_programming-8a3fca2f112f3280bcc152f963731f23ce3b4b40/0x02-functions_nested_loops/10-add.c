#include "main.h"
/**
 * add - add two integers
 * @num1: one of two intergers
 * @num2: interger
 * Return: Always sum (Success)
 */

int add(int num1, int num2)
{
int sum;
sum = num1 + num2;

return (sum);
}
