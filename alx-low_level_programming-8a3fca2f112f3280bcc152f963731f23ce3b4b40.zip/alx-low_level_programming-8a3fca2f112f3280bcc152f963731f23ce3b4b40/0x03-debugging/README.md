read a debug file
