#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>

void positive_or_negative(int i);
int largest_number(int, int, int);
int convert_day(int, int);
void print_remaining_days(int, int, int);

#endif /* MAIN_H */
