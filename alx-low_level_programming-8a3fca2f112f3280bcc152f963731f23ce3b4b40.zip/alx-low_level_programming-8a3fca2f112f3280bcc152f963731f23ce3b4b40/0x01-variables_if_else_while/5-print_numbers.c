#include <stdio.h>

/**
 * main - Entry point
 *
 * Return: Always 0 (Success)
 */

int main(void)
{
int a = 0;
for (a = 0; a < 10; a++)
{
	printf("%d", a);
}
printf("\n");
return (0);
}
