#include <stdio.h>

/**
 * main - Entry point
 *
 * Return: Always 0 (Success)
 *
 */

int main(void)
{
char ch;
char space = '\n';
for (ch = 'z' ; ch >= 'a' ; ch--)
{
	putchar(ch);
}
putchar(space);
return (0);
}
