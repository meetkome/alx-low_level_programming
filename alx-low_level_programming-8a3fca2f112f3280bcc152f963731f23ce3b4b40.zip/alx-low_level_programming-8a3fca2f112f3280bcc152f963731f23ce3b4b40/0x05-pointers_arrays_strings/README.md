a readme file for pointer and array
