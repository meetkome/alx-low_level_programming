#include "main.h"

/**
 * reset_to_98 - Takes pointer to an int
 * @n: puntero
 * Return: 0
 *
 */

void reset_to_98(int *n)
{
	*n = 98;
}
