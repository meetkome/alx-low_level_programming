#include "main.h"

/**
 * main - checks code
 *
 * Return: Always o
 */

int main(void)

{
char *str;

str = "I do not fear computers. I fear the lack of them - Isaac Asimov";
_puts(str);
return (0);

}
