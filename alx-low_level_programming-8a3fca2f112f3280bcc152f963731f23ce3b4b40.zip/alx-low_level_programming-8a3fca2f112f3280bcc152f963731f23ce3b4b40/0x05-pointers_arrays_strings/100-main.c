#include <stdio.h>
<include "main.h"

/**
 * main - check the code
 *
 * Return: Always o
 */

{
int nb;
nb = _atoi("98");
printf("%d\n", nb);

nb = _atoi("-402");
printf("%d\n", nb);
nb = _atoi("          ------++++++-----+++++--98");
printf("%d\n", nb);
nb = _atoi("214748364");
printf("%d\n", nb);
nb = _atoi("0");
printf("%d\n", nb);
nb = _atoi("Suite 402");
printf("%d\n", nb);
nb = _atoi("         +      +    -    -98 Battery Street; San Francisco, CA 94111 - USA             ");
printf("%d\n", nb);
nb = _atoi("---++++ -++ Sui - te -   402 #cisfun :)");
printf("%d\n", nb);
return (0);
}


