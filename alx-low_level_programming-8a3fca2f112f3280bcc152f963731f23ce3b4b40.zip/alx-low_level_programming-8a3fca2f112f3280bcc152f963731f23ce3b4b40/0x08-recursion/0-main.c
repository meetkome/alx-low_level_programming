#include "main.h"

/**
 * main - checks code
 * Return: 0 Always
 */

int main(void)

{
	_puts_recursion("Puts with recursion");
	return (0);
}
